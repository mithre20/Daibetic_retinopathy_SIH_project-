Place sample/test fundus images here (e.g. `sample_fundus.jpg`) and dataset
label CSVs (see ../docs/DATASETS.md) for local testing. No images are
bundled in this repo.
